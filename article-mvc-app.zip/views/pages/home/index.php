<h1><?= ucfirst($title) ?></h1>

<p><?= $content ?? null; ?></p>