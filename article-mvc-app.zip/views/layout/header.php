<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title ?? 'Boink' ?></title>
</head>
<header>
    <!-- Navigation Bar -->
    <nav>
        <ul>
            <li><a href="/home/index">Home</a></li>
            <li><a href="/articles/index">Articles</a></li>
        </ul>
    </nav>
</header>